package com.training.ui;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashSet;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.training.entity.Player;

/**
 * Servlet implementation class Demo5
 */
@WebServlet("/Demo5")
public class Demo5 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		Set<Player> players=new HashSet<>();
		Player p1=new Player(1,"Dhoni",5,500,121,false);
		Player p2=new Player(2,"Virat Kohli",10,900,203,false);
		Player p3=new Player(3,"Yuvi",15,800,820,false);
		Player p4=new Player(4,"Dhawan",20,1300,532,false);
		Player p5=new Player(5,"Jadhav",30,4200,442,false);
		Player p6=new Player(6,"Bhuvenshwar",740,500,912,false);
		Player p7=new Player(7,"Gautam Gambir",523,150,52,false);
		Player p8=new Player(8,"Sachin",19,1700,912,false);
		Player p9=new Player(9,"Kumar",50,5800,512,false);
		Player p10=new Player(10,"suresh",51,1210,162,false);
		Player p11=new Player(11,"Rahul",60,1280,192,false);
		players.add(p1);
		players.add(p2);
		players.add(p3);
		players.add(p4);
		players.add(p5);
		players.add(p6);
		players.add(p7);
		players.add(p8);
		players.add(p9);
		players.add(p10);
		players.add(p11);
		response.setContentType("text/html");
		 out.print("<html>");
		 out.print("<head>");
		 out.print("<link href='Style.css' rel='Stylesheet'>");
		 out.print("</head>");
		 out.print("<body>");
		 out.print("<body>");
		 out.print("</html>");
		 
		 out.print("<table border= '2'>");
		  out.print("<tr>");
		  out.print("<td>"+"PlayerID"+"</td>");
		  out.print("<td>"+"PlayerName"+"</td>");
		  out.print("<td>"+"noOfMatches"+"</td>");
		  out.print("<td>"+"totalRunsScored"+"</td>");  
		  out.print("<td>"+"numberOfWickets"+"</td>");
		  out.print("<td>"+"captain"+"</td>");
		  out.print("<td>"+"AverageBattingRating"+"</td>");
		  out.print("<td>"+"AverageBowlingRating"+"</td>");
		  out.print("</tr>");
		 
		  for (Player playerData : players) {
			  out.print("<tr>");
			  out.print("<th>"+playerData.getPlayerId()+"</th>");
			  out.print("<th>"+playerData.getPlayerName()+"</th>");
			  out.print("<th>"+playerData.getNoOfMatches()+"</th>");
			  out.print("<th>"+playerData.getNumberOfWickets()+"</th>");
			  out.print("<th>"+playerData.getTotalRunsScored()+"</th>");
			  out.print("<th>"+playerData.isCaptain()+"</th>");
			  out.print("<th>"+playerData.getBattingRating()+"</th>");
			  out.print("<th>"+playerData.getBowlingRating()+"</th>");
			  out.print("</tr>");
			
		}
		
		 
	}

}
