package com.training.entity;

public class Player {
	int playerId;
	String playerName;
	int noOfMatches;
	int totalRunsScored;
	int numberOfWickets;
	boolean captain;

	public int getPlayerId() {
		return playerId;
	}

	public void setPlayerId(int playerId) {
		this.playerId = playerId;
	}

	public String getPlayerName() {
		return playerName;
	}

	public void setPlayerName(String playerName) {
		this.playerName = playerName;
	}

	public int getNoOfMatches() {
		return noOfMatches;
	}

	public void setNoOfMatches(int noOfMatches) {
		this.noOfMatches = noOfMatches;
	}

	public int getTotalRunsScored() {
		return totalRunsScored;
	}

	public void setTotalRunsScored(int totalRunsScored) {
		this.totalRunsScored = totalRunsScored;
	}

	public int getNumberOfWickets() {
		return numberOfWickets;
	}

	public void setNumberOfWickets(int numberOfWickets) {
		this.numberOfWickets = numberOfWickets;
	}

	public boolean isCaptain() {
		return captain;
	}

	public void setCaptain(boolean captain) {
		this.captain = captain;
	}

	public Player(int playerId, String playerName, int noOfMatches,
			int totalRunsScored, int numberOfWickets, boolean captain) {
		super();
		this.playerId = playerId;
		this.playerName = playerName;
		this.noOfMatches = noOfMatches;
		this.totalRunsScored = totalRunsScored;
		this.numberOfWickets = numberOfWickets;
		this.captain = captain;
	}

	public Player() {
		super();
	}

	@Override
	public String toString() {
		return "Player [playerId=" + playerId + ", playerName=" + playerName
				+ ", noOfMatches=" + noOfMatches + ", totalRunsScored="
				+ totalRunsScored + ", numberOfWickets=" + numberOfWickets
				+ ", captain=" + captain + "]";
	}

	public String getBattingRating(){
		double avg=this.totalRunsScored/this.noOfMatches;
				if(avg>90){
					return"Best";
				}
		else if(avg>50){
					return "Good";
					
				}
		else if(avg>25){
			return "Average";
			
		}
		else{
			return "Poor";
		}
	}
				public String getBowlingRating(){
					double avg=this.numberOfWickets/this.noOfMatches;
							if(avg>80){
								return"Best";
							}
					else if(avg>40){
								return "Good";
								
							}
					else if(avg>15){
						return "Average";
						
					}
					else{
						return "Poor";
					}
	}
}
