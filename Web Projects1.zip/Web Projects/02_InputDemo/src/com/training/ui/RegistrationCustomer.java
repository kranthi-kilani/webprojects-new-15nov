package com.training.ui;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.text.DefaultEditorKit.CutAction;

import com.training.entity.Customer;

/**
 * Servlet implementation class RegistrationCustomer
 */
@WebServlet("/Reg")
public class RegistrationCustomer extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		Customer customer = new Customer();

		String strid = request.getParameter("txtId");
		if (strid != null) {
			int id = Integer.parseInt(strid);
			customer.setId(id);
		}

		String strname = request.getParameter("txtName");
		if (strname != null) {
			customer.setName(strname);
		}

		String gender = request.getParameter("rad_Gender");
		if (gender != null) {
			int d = Integer.parseInt(gender);
			customer.setGender(d);
		}

		String strPrivileged = request.getParameter("chckPrivileged");
		if (strPrivileged == null) {
			customer.setPrivilege(false);
		} else {

			customer.setPrivilege(true);
		}
		String strphno = request.getParameter("txtPhno");
		if (strphno != null) {
			customer.setPhone(strphno);

		}
		String stremail = request.getParameter("txtEmail");
		if (stremail != null) {
			customer.setEmail(stremail);

		}
		String straddress = request.getParameter("txtAddress");
		if (straddress != null) {
			customer.setAddress(straddress);

		}

		String strDoj = request.getParameter("txtDoj");
		if (strDoj != null) {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			Date doj = null;
			try {
				doj = sdf.parse(strDoj);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			customer.setDateOfJoining(doj);

		}

		String strdesc = request.getParameter("txtDesc");
		if (strdesc != null) {
			customer.setDescription(strdesc);

		}

		String strbal = request.getParameter("txtBalance");
		if (strbal != null) {
			double bal = Double.parseDouble(strbal);
			customer.setBalanceAmount(bal);
		}

		String strrate = request.getParameter("txtRating");
		if (strrate != null) {
			int rate = Integer.parseInt(strrate);
			customer.setCustomerRating(rate);
		}

		out.println("\tId\t:"+customer.getId() + "\n" + "\tName\t:"+customer.getName() + "\n"
				+ "\tGender\t:"+customer.getGender() + "\n" +"\tEmail\t:"+ customer.getEmail() + "\n"
				+ "\tPhone\t:"+customer.getPhone() + "\n" + "\tAddress\t:"+customer.getAddress() + "\n"
				+"\tBalaAmount\t:"+ customer.getBalanceAmount() + "\n"
				+ "\tRating\t:"+customer.getCustomerRating() + "\n"
				+ "\tDescription\t:"+customer.getDescription());

	}

}
