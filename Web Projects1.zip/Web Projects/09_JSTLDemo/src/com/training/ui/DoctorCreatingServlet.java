package com.training.ui;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class DoctorCreatingServlet
 */
@WebServlet("/DoctorCreatingServlet")
public class DoctorCreatingServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
List<Doctor> doctors=new ArrayList<>();
		Doctor d1 = new Doctor();
		Doctor d2 = new Doctor();
		Doctor d3 = new Doctor();
		Doctor d4 = new Doctor();
		Doctor d5 = new Doctor();
		d1.setId(101);
		d1.setName("kranthi");
		d1.setQualification("M.B.B.S");
		d1.setGender("F");
		d1.setExperience(15);
		d1.setFee(100.0);
	
		d2.setId(102);
		d2.setName("Priya");
		d2.setQualification("M.B.B.S");
		d2.setGender("F");
		d2.setExperience(25);
		d2.setFee(1000.0);
		
		
		
		d3.setId(103);
		d3.setName("Anusha");
		d3.setQualification("M.B.B.S");
		d3.setGender("F");
		d3.setExperience(5);
		d3.setFee(200.0);
		
		
		d4.setId(104);
		d4.setName("Chanu");
		d4.setQualification("M.B.B.S");
		d4.setGender("M");
		d4.setExperience(25);
		d4.setFee(7000.0);
		
		d5.setId(105);
		d5.setName("Chaitu");
		d5.setQualification("M.B.B.S");
		d5.setGender("M");
		d5.setExperience(10);
		d5.setFee(1200.0);
	
		doctors.add(d1);
		doctors.add(d2);
		doctors.add(d3);
		doctors.add(d4);
		doctors.add(d5);
		
		
		request.setAttribute("DOCTOR", doctors);
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("Display4.jsp");
		dispatcher.forward(request, response);

	}

}
