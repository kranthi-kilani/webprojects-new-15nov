package com.training.ui;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.wsdl.extensions.http.HTTPAddress;

/**
 * Servlet implementation class DoctorAddServlet
 */
@WebServlet("/DoctorAddServlet")
public class DoctorAddServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	Doctor d=new Doctor();
		
		
	int id=Integer.parseInt(request.getParameter("txt1"));
	String name=request.getParameter("txt2");
	String qualification=request.getParameter("txt3");
	String gender=request.getParameter("txt4");
	
	double fee=Double.parseDouble(request.getParameter("txt5"));
	
	int experience=Integer.parseInt(request.getParameter("txt6"));
	
	d.setId(1);
	d.setName("kranthi");
	d.setQualification("M.B.B.S");
	d.setFee(500.0);
	d.setGender("M");
	d.setExperience(10);
	
	HttpSession session=request.getSession(true);
	List<Doctor> doctors=null;
	doctors=(List<Doctor>) session.getAttribute("DOCTORS");
	if(doctors==null){
		doctors=new ArrayList<Doctor>();
		session.setAttribute("DOCTORS", doctors);
	}
	doctors.add(d);
	RequestDispatcher dispatcher=request.getRequestDispatcher("Display4.jsp");
	dispatcher.forward(request, response);
	
	
	}

}
